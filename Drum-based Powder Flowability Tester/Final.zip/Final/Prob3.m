% Elliptic Boundary Value
clear
clc
close all

% Solve the elliptic BVP with the Finite Difference Method
    % -u"(x)+u(x) = f(x), 0<x<1
    % u(0) = 1, u(1) = -1
        % For the function f(x) = pi^2*cos(pi*x) + cos(pi*x)
% Discretize the interval (0,1) into N subintervals with N = 4,8,16,32
% A) Plot the numerical solution for each mesh
x_bound = [0,1]; 
sol4 = Elliptic_FDM(x_bound,4); sol16 = Elliptic_FDM(x_bound,16); 
sol8 = Elliptic_FDM(x_bound,8); sol32 = Elliptic_FDM(x_bound,32); 
u_exact = Exact_Sol(linspace(0,1,129));

figure(1)
plot(linspace(0,1,129),u_exact,'-k')
hold on
plot(linspace(0,1,33),sol32,'--*c')
plot(linspace(0,1,17),sol16,'--xb')
plot(linspace(0,1,9),sol8,'--og')
plot(linspace(0,1,5),sol4,'--+r')
legend('Exact','N = 32','N = 16', 'N = 8', 'N = 4')
ylim([-1.5,1.5])

% B) Compute the 'root-mean-square' error for each mesh given
    % u_exact(x) = cos(pi*x)
    e4 = zeros(1,5); e8 = zeros(1,9); e16 = zeros(1,17); e32 = zeros(1,33);
    for i = 1:33
        e32(i) = sol32(i) - u_exact(4*(i-1)+1);
    end
    for i = 1:17
        e16(i) = sol16(i) - u_exact(8*(i-1)+1);
    end
    for i = 1:9
        e8(i) = sol8(i) - u_exact(16*(i-1)+1);
    end
    for i = 1:5
        e4(i) = sol4(i) - u_exact(32*(i-1)+1);
    end
    E4 = sqrt(1/5 * sum(e4.^2)); E8 = sqrt(1/9 * sum(e8.^2));
    E16 = sqrt(1/17 * sum(e16.^2)); E32 = sqrt(1/33 * sum(e32.^2));
    disp(['RMS error for N = 4 is ',num2str(E4)])
    disp(['RMS error for N = 8 is ',num2str(E8)])
    disp(['RMS error for N = 16 is ',num2str(E16)])
    disp(['RMS error for N = 32 is ',num2str(E32)])

    % Show that the numerical method converges with the correct rate
    figure(2)
    semilogy([4 8 16 32],[E4 E8 E16 E32],'--*r')
    title('Semilogy Plot of Error vs. Mesh Size')
    xlabel('Mesh Size (# Intervals)')
    ylabel('Error (Log(RMS error))')
    xlim([0,40])

function u_approx = Elliptic_FDM(x_bounds,intervals)
    x0 = x_bounds(1); xL = x_bounds(2);
    N = intervals;
    h = (xL - x0)/N;

    % Mesh
    x = linspace(x0,xL,N+1);

    % Set up to solve
    A = diag(ones(N-1,1)*(2+h^2)) + diag(ones(N-2,1)*(-1),1) + diag(ones(N-2,1)*(-1),-1);
    b = zeros(N-1,1);
    for i=1:N-1
        f = pi^2*cos(pi*x(i+1))+cos(pi*x(i+1));
        b(i,1) = h^2*f;
    end
    b(1,1) = b(1,1) + 1; % Add Boundary Conditions
    b(end,1) = b(end,1) -1; % Add Boundary Conditions

    v = A\b;
    u_approx = [1;v;-1];
end

function u_exact = Exact_Sol(x)
    u_exact = cos(pi.*x);
end