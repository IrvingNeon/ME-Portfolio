% Gauss-Seidel Method
% Inputs: full or sparse matrix A, RHS b,
%         number of G-S iterations k
% Output: solution x
function [X] = Gauss_Seidel_4_dec(A,b,kmax)
epsilon = 1.e-4;    % set tolerance
n = length(b);      % find n
delta=1.e-10;       % tolerance for small parameters
x = zeros(n,1);  % initialize vector x


for k=1:kmax
    y=x;
    for i=1:n
        sum=b(i);
        diag=A(i,i);
        if abs(diag)<delta
            disp ('diagonal element too small')
            return
        end
        for j=1:i-1
           sum=sum-A(i,j)*x(j);
        end
        x(i)=sum/diag;
        for j=i+1:n
            sum=sum-A(i,j)*x(j);
        end            
        x(i)=sum/diag;
    end
    X(:,k)=x;
    if norm(x-y)<epsilon
       % fprintf('the matrix storing Gauss-Seidel iterates as columes X=\n')
       % disp(X)     
       fprintf('Gauss-Seidel convergence at iteration k=%1.f\n',k)
       disp('the actual solution (to four decimal places rounded) is obtained x=')
       disp(x)
       return
    elseif k == kmax
        disp('Gauss-Seidel did not converge in the user-permitted number of iterations.')
    end
end
end