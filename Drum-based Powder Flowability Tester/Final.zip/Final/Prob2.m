% Poisson Equation
close all
clear
clc
% Solve using forward-Euler in time and central-difference in space
% x [0,1], y [1,2], M=N=10,20,40,80

x_bound = [0,1]; y_bound = [1,2];
% Solve
sol_10 = poisson(x_bound, y_bound, 10,10);
sol_20 = poisson(x_bound, y_bound, 20,20);
sol_40 = poisson(x_bound, y_bound, 40,40);
sol_80 = poisson(x_bound, y_bound, 80,80);
x_ex = linspace(0,1,321); y_ex = linspace(1,2,321);
u_ex = zeros(321,321);
for i = 1:321
    for j = 1:321
        u_ex(i,j) = exact_sol(x_ex(i),y_ex(j));
    end
end
figure(1)
sgtitle('Approximate Solutions (Blue) for 4 Different Meshes')
subplot(2,2,1)
surf(linspace(0,1,11),linspace(1,2,11),sol_10,'EdgeColor','none','FaceColor','b','FaceAlpha',0.3)
hold on
surf(x_ex,y_ex,u_ex,'EdgeColor','none','FaceColor','k','FaceAlpha',0.3)
xlabel('X')
ylabel('Y')
title('10 Space Intervals')
subplot(2,2,2)
surf(linspace(0,1,21),linspace(1,2,21),sol_20,'EdgeColor','none','FaceColor','b','FaceAlpha',0.3)
hold on
surf(x_ex,y_ex,u_ex,'EdgeColor','none','FaceColor','k','FaceAlpha',0.3)
xlabel('X')
ylabel('Y')
title('20 Space Intervals')
subplot(2,2,3)
surf(linspace(0,1,41),linspace(1,2,41),sol_40,'EdgeColor','none','FaceColor','b','FaceAlpha',0.3)
hold on
surf(x_ex,y_ex,u_ex,'EdgeColor','none','FaceColor','k','FaceAlpha',0.3)
xlabel('X')
ylabel('Y')
title('40 Space Intervals')
subplot(2,2,4)
surf(linspace(0,1,81),linspace(1,2,81),sol_80,'EdgeColor','none','FaceColor','b','FaceAlpha',0.3)
hold on
surf(x_ex,y_ex,u_ex,'EdgeColor','none','FaceColor','k','FaceAlpha',0.3)
xlabel('X')
ylabel('Y')
title('80 Space Intervals')

% Error
e10 = zeros(11,11); e20 = zeros(21,21); e40 = zeros(41,41); e80 = zeros(81,81);
for i = 1:11
    for j = 1:11
        e10(j,i) = sol_10(j,i) - u_ex((32*(j-1))+1,(32*(i-1))+1);
    end
end
for i = 1:21
    for j = 1:21
        e20(j,i) = sol_20(j,i) - u_ex((16*(j-1))+1,(16*(i-1))+1);
    end
end
for i = 1:41
    for j = 1:41
        e40(j,i) = sol_40(j,i) - u_ex((8*(j-1))+1,(8*(i-1))+1);
    end
end
for i = 1:81
    for j = 1:81
        e80(j,i) = sol_80(j,i) - u_ex((4*(j-1))+1,(4*(i-1))+1);
    end
end
figure(2)
sgtitle('Absolute Error for Meshes (Note the Scale)')
subplot(2,2,1)
surf(linspace(0,1,11),linspace(1,2,11),e10,'EdgeColor','none','FaceColor','b','FaceAlpha',0.3)
title('10 Space Intervals')
subplot(2,2,2)
surf(linspace(0,1,21),linspace(1,2,21),e20,'EdgeColor','none','FaceColor','b','FaceAlpha',0.5)
title('20 Space Intervals')
subplot(2,2,3)
surf(linspace(0,1,41),linspace(1,2,41),e40,'EdgeColor','none','FaceColor','b','FaceAlpha',0.5)
title('40 Space Intervals')
subplot(2,2,4)
surf(linspace(0,1,81),linspace(1,2,81),e80,'EdgeColor','none','FaceColor','b','FaceAlpha',0.5)
title('80 Space Intervals')

% Ratios 
E10 = sqrt( 1/11 * sum( 1/11 * sum(e10.^2,1),2));
E20 = sqrt( 1/21 * sum( 1/21 * sum(e20.^2,1),2));
E40 = sqrt( 1/41 * sum( 1/41 * sum(e40.^2,1),2));
E80 = sqrt( 1/81 * sum( 1/81 * sum(e80.^2,1),2));
disp(['E(20)/E(10) = ',num2str(E20/E10)])
disp(['E(40)/E(20) = ',num2str(E40/E20)])
disp(['E(80)/E(40) = ',num2str(E80/E40)])

% Convergence Rate
Rate1 = log10(E20/E10)/log10(2); % = -2.1510
Rate2 = log10(E40/E20)/log10(2); % = -2.0176
Rate3 = log10(E80/E40)/log10(2); % = -1.9954
disp('For each decrease in mesh size by 2, the convergence rate is approximately 2.')
disp('From N = 10 to N = 20 the convergence rate was -2.1510, for 20 to 40 it was -2.0176,')
disp('and for 40 to 80 it was -1.99544.')




function u_exact = exact_sol(x,y)
    u_exact = cos(5*pi*x)*sin(7*pi*y);
end

function u_approx = poisson(x_bound, y_bound, x_ints, y_ints)
    m=x_ints-1;n=y_ints-1;
    h=(x_bound(2)-x_bound(1))/x_ints;h2=h^2;k=(y_bound(2)-y_bound(1))/y_ints;
    r=h2/k^2;s=2*(1+r);                   
    x=x_bound(1)+(x_bound(2)-x_bound(1))*(0:x_ints)/x_ints;
    y=y_bound(1)+(y_bound(2)-y_bound(1))*(0:y_ints)/y_ints;
    z=zeros(1,m-2);                        
    a=zeros(m*n,m*n);b=zeros(m*n,1);
    for i=2:m-1
      for j=2:n-1
        a(i+(j-1)*m,:)=[zeros(1,i-1+(j-2)*m) r z 1 -s 1 z r ...
         zeros(1,(n-j)*m-i)];
        b(i+(j-1)*m)=h2*f(x(i+1),y(j+1));
      end
    end
    % outer ring
    j=1;                    % bottom row
    for i=2:m-1
      a(i+(j-1)*m,:)=[zeros(1,i-2) 1 -s 1 z r zeros(1,(n-j)*m-i)];
      b(i+(j-1)*m)=h2*f(x(i+1),y(j+1))-r*gbottom(x(i+1));
    end
    j=n;                    % top row
    for i=2:m-1
      a(i+(j-1)*m,:)=[zeros(1,i-1+(j-2)*m) r z 1 -s 1 zeros(1,m-i-1)];
      b(i+(j-1)*m)=h2*f(x(i+1),y(j+1))-r*gtop(x(i+1));
    end
    i=1;                    % left side
    for j=2:n-1
      a(i+(j-1)*m,:)=[zeros(1,i-1+(j-2)*m) r z 0 -s 1 z r ...
       zeros(1,(n-j)*m-i)];
      b(i+(j-1)*m)=h2*f(x(i+1),y(j+1))-gleft(y(j+1));
    end
    i=m;                    % right side
    for j=2:n-1
      a(i+(j-1)*m,:)=[zeros(1,(j-1)*m-1) r z 1 -s 0 z r ...
       zeros(1,(n-j)*m-i)];
      b(i+(j-1)*m)=h2*f(x(i+1),y(j+1))-gright(y(j+1));
    end
    % four corners
    i=1;j=1;                % bottom left
    a(i+(j-1)*m,:)=[-s 1 z r zeros(1,(n-1)*m-1)];
    b(i+(j-1)*m)=h2*f(x(i+1),y(j+1))-r*gbottom(x(i+1))-gleft(y(j+1));
    i=m;j=1;                % bottom right
    a(i+(j-1)*m,:)=[z 1 -s 0 z r zeros(1,(n-2)*m)];
    b(i+(j-1)*m)=h2*f(x(i+1),y(j+1))-r*gbottom(x(i+1))-gright(y(j+1));
    i=1;j=n;                % top left
    a(i+(j-1)*m,:)=[zeros(1,(n-2)*m) r z 0 -s 1 zeros(1,m-2)];
    b(i+(j-1)*m)=h2*f(x(i+1),y(j+1))-r*gtop(x(i+1))-gleft(y(j+1));
    i=m;j=n;                % top right
    a(i+(j-1)*m,:)=[zeros(1,(n-1)*m-1) r z 1 -s];
    b(i+(j-1)*m)=h2*f(x(i+1),y(j+1))-r*gtop(x(i+1))-gright(y(j+1));
    v=a\b;                  % solve for solution Poisson
    w=zeros(m,n);
    for i=1:m               % put solution into mesh 
      for j=1:n
        w(i,j)=v(i+(j-1)*m);
      end
    end
    % u_approx = [zeros(1,x_ints-1);w;zeros(1,x_ints-1)];
    u_approx=[gbottom(x(2:x_ints))' w gtop(x(2:x_ints))']; % add boundary conditions 
    u_approx = [gleft(y);u_approx;gright(y)];

    function u=f(x,y)       % right hand side of equation
        u=-74*pi^2*cos(5*pi*x).*sin(7*pi*y);
    end
    function u=gbottom(x)   % bottom of rectangle
        u=zeros(1,length(x));
    end
    function u=gtop(x)      % top of rectangle
        u=zeros(1,length(x));
    end
    function u=gleft(y)     % left side of rectangle
        u=sin(7*pi*y);
    end
    function u=gright(y)    % right side of rectangle
        u=-1*sin(7*pi*y); 
    end
end

