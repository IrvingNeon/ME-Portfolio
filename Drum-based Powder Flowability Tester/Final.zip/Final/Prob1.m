% Heat Equation
close all
clear
clc
% Solve using forward-Euler in time and central-difference in space
% x [0,1], t [0,0.2], 900 in time, 4, 8, 16, 32 space intervals
    % Plot the solutions and errors in time and space
    % Show the ratios of error are about 4

x_bound = [0,1]; t_bound = [0,0.2]; t_steps = 900;
% Solve
t = linspace(0,0.2,900); x4 = linspace(0,1,5); x8 = linspace(0,1,9);
x16 = linspace(0,1,17); x32 = linspace(0,1,33); 
sol_4 = PDE_heat(x_bound, t_bound, 4, t_steps);
sol_8 = PDE_heat(x_bound, t_bound, 8, t_steps);
sol_16 = PDE_heat(x_bound, t_bound, 16, t_steps);
sol_32 = PDE_heat(x_bound, t_bound, 32, t_steps);
x_ex = linspace(0,1,129); u_ex = zeros(129,900);
for i = 1:900
    for j = 1:129
        u_ex(j,i) = exact_sol(x_ex(j),t(i));
    end
end
figure(1)
sgtitle('Approximate Solutions (Blue) for 4 Different Meshes')
subplot(2,2,1)
surf(x4,t,sol_4','EdgeColor','none','FaceColor','b','FaceAlpha',0.3)
hold on
surf(x_ex,t,u_ex','EdgeColor','none','FaceColor','k','FaceAlpha',0.3)
xlabel('Space')
ylabel('Time')
title('4 Space Intervals')
subplot(2,2,2)
surf(x8,t,sol_8','EdgeColor','none','FaceColor','b','FaceAlpha',0.5)
hold on
surf(x_ex,t,u_ex','EdgeColor','none','FaceColor','k','FaceAlpha',0.5)
xlabel('Space')
ylabel('Time')
title('8 Space Intervals')
subplot(2,2,3)
surf(x16,t,sol_16','EdgeColor','none','FaceColor','b','FaceAlpha',0.5)
hold on
surf(x_ex,t,u_ex','EdgeColor','none','FaceColor','k','FaceAlpha',0.5)
xlabel('Space')
ylabel('Time')
title('16 Space Intervals')
subplot(2,2,4)
surf(x32,t,sol_32','EdgeColor','none','FaceColor','b','FaceAlpha',0.5)
hold on
surf(x_ex,t,u_ex','EdgeColor','none','FaceColor','k','FaceAlpha',0.5)
xlabel('Space')
ylabel('Time')
title('32 Space Intervals')

% Error
e4 = zeros(5,900); e8 = zeros(9,900); e16 = zeros(17,900); e32 = zeros(33,900);
for i = 1:900
    for j = 1:5
        e4(j,i) = sol_4(j,i) - u_ex((32*(j-1))+1,i);
    end
    for j = 1:9
        e8(j,i) = sol_8(j,i) - u_ex((16*(j-1))+1,i);
    end
    for j = 1:17
        e16(j,i) = sol_16(j,i) - u_ex((8*(j-1))+1,i);
    end
    for j = 1:33
        e32(j,i) = sol_32(j,i) - u_ex((4*(j-1))+1,i);
    end
end
figure(2)
sgtitle('Absolute Error for Meshes')
subplot(2,2,1)
surf(x4,t,e4','EdgeColor','none','FaceColor','b','FaceAlpha',0.3)
title('4 Space Intervals')
subplot(2,2,2)
surf(x8,t,e8','EdgeColor','none','FaceColor','b','FaceAlpha',0.5)
title('8 Space Intervals')
subplot(2,2,3)
surf(x16,t,e16','EdgeColor','none','FaceColor','b','FaceAlpha',0.5)
title('16 Space Intervals')
subplot(2,2,4)
surf(x32,t,e32','EdgeColor','none','FaceColor','b','FaceAlpha',0.5)
title('32 Space Intervals')

% Ratios 
E4 = sqrt( 0.2/t_steps * sum( 1/4 * sum(e4.^2,1),2));
E8 = sqrt( 0.2/t_steps * sum( 1/8 * sum(e8.^2,1),2));
E16 = sqrt( 0.2/t_steps * sum( 1/16 * sum(e16.^2,1),2));
E32 = sqrt( 0.2/t_steps * sum( 1/32 * sum(e32.^2,1),2));
disp(['E(8)/E(4) = ',num2str(E8/E4)])
disp(['E(16)/E(8) = ',num2str(E16/E8)])
disp(['E(32)/E(16) = ',num2str(E32/E16)])


function u_exact = exact_sol(x,t)
    u_exact = exp(-1*pi^2*t)*sin(pi*x);
end

function u_approx = PDE_heat(x_bound, t_bound, x_ints, t_steps)
    x_step_sz = (x_bound(2) - x_bound(1)) / x_ints;
    t_step_sz = (t_bound(2) - t_bound(1)) / t_steps;
    N_t = t_steps-1; N_x = x_ints - 1;
    sigma = t_step_sz / (x_step_sz^2);

    % Set up matrix
    a = diag((1-2*sigma)*ones(N_x,1))+diag(sigma*ones(N_x-1,1),1)...
            + diag(sigma*ones(N_x-1,1),-1);
    left_side = zeros(1,N_t+1); right_side = zeros(1,N_t+1);
    space = x_bound(1) + (1:N_x)*x_step_sz;
    sol_(:,1) = sin(pi.*space)';
    
    % Solve
    for i = 1:N_t
        sol_(:,i+1) = a*sol_(:,i);
    end
    u_approx = [left_side;sol_;right_side];
end

