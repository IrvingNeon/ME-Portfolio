% Problem 4

% Displacement of beam = y(x)
% y(x) satisfies EIy""(x) = f(x)
% Boundary condition: y(0) = y'(0) = y(L) = y'(L) = 0
% Finite diference discretization
    % h = L/N, x_i = ih for i = 0,...,N
    % For x_2,...x_N-2
    % y"" = [y(x_i-2) - 4y(x_i-1) + 6y(x_i) - 4y(x_i+1) + y(x_i+2) ] / h^4
    % For x_1
    % y'" = [12y(x_i) - 6y(x_i+1) + 4/3y(x_i+2) ] / h^4
    % For x_N-1
    % y'" = [-12y(x_i) + 6y(x_i-1) + 4/3y(x_i-2) ] / h^4

% Write the resulting linear system
%   Given x_i = x_0 + h*i  and  y_i = y(x_0 + h*i) 
%       where i is an integer i = 0,1,...,N
%       and h = (x_N - x_0) / N
% [ 12  -6  4/3   0   0   0   0  0 ... 0  [ y_1       [ h^4/(E*I) * f(x_1)
%   -4   6   -4   1   0   0   0  0 ... 0    y_2         h^4/(E*I) * f(x_2)
%    1  -4    6  -4   1   0   0  0 ... 0    y_3         h^4/(E*I) * f(x_3)
%    0   1   -4   6  -4   1   0  0 ... 0    y_4         h^4/(E*I) * f(x_4)
%    0   0    1  -4   6  -4   1  0 ... 0    y_5     =   h^4/(E*I) * f(x_5)
%    0   0    0   1  -4   6  -4  1 ... 0    y_6         h^4/(E*I) * f(x_6)
%    .                          .      .     .                   .
%    .                            .    .     .                   .
%    .                              .  .     .                   .
%    0  ...  0   0   0   1    -4  6   -4    y_N-2       h^4/(E*I) * f(x_N-2)
%    0  ...  0   0   0   0   4/3  6  -12 ]  y_N-1 ]     h^4/(E*I) * f(x_N-1) ]
                                        
    

% Consider L = 10 [m], depth d = 0.05 [m], width b = 0.1 [m]
%          E = 2e11 [N/m^2], I = bd^3/12, f(x) = 7850bd * 9.81
% Solve the system for displacements y_i = y(x_i) with N = 10 with Jacobi
%          and Gauss-Seidel.
L = 10; d = 0.05; b = 0.1; E = 2*10^11; N = 10;
I = b*d^3/12; f = 7850*b*d*9.81*ones(N-1,1);
h = 10 / N;
A =  [ 12  -6  4/3   0   0   0   0    0   0; ... 
       -4    6  -4   1   0   0    0   0   0; ... 
        1   -4   6  -4   1   0    0   0   0; ... 
        0    1  -4   6  -4   1    0   0   0; ... 
        0    0   1  -4   6  -4    1   0   0; ... 
        0    0   0   1  -4   6   -4   1   0; ...
        0    0   0   0   1  -4    6  -4   1; ...
        0    0   0   0   0   1   -4   6  -4; ...
        0    0   0   0   0   0  4/3   6  -12];
b = f * h^4 / E / I;

x_Gauss_Seidel = Gauss_Seidel_4_dec(A,b',100000);
x_Jacobi = Jacobi(A,b',100000);
% Which converges?
disp('%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%')
disp('For up to 100,000 iterations, the Jacobi method does not converge.')
disp('The Gauss-Seidel method converged in 6273 iterations.')

% How many steps are required to converge to six decimal places?
disp('%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%')
disp('For 6 decimal places, ')
x_Gauss_Seidel = Gauss_Seidel_6_dec(A,b',100000);
