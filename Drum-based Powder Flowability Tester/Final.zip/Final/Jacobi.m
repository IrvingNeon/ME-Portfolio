% Jacobi Method
% Inputs: full or sparse matrix A, RHS b,
%         number of Jacobi iterations k
% Output: solution x
function [X] = Jacobi(A,b,k)
epsilon = 1.e-4;%1.e-10;     % set tolerance
n = length(b);      % find n
X = zeros(n,k);     % initialize the matrix storing iterates as columns
D = diag(A);        % extract diagonal of A
r = A - diag(D);    % r is the remainder
xold = zeros(n,1);  % initialize vector x

%rJ=spectralRadiusJacobi(A);
%if rJ<1 
    %fprintf('\n The Jacobi iterations will converge with tolerance %1.16f \n',epsilon) 
    %fprintf('since the spectral radius of the iteration matrix B_J is R_J=%1.6f \n',rJ)


    for j=1:k           % loop for Jacobi iteration
        xnew = (b'-r*xold)./D;
        if norm(xold-xnew) < epsilon
           %disp('convergence at iteration j =') 
           %disp(j)
           fprintf('Jacobi convergence at iteration k=%1.f\n',j)
           disp('the actual solution (to four decimal places rounded) is obtained x=')
           disp(xnew)
           xold = xnew;
           X(:,j) = xold';
           return
        elseif k == j
            disp('Jacobi did not converge in the user-permitted number of iterations.')
        end
        xold = xnew;
        X(:,j) = xold';
    end   
end                 % End of Jacobi iteration loop
